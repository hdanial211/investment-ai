# 🤖 Investment AI — Grid Trading Bot
### Sistem Auto-Trading Crypto (BTC, ETH, XRP, SOL) di Luno Malaysia

---

## 📋 KEPERLUAN SISTEM

| Perkara | Keperluan |
|---|---|
| OS | Windows 10/11 |
| Python | 3.11 atau 3.12 |
| Node.js | 18.x ke atas |
| Akaun | Luno Malaysia (https://luno.com) |
| Modal Minimum | RM 150 (RM 35 × 4 pair) |

---

## ⚙️ CARA SETUP (Ikut Langkah Demi Langkah)

### LANGKAH 1 — Dapatkan API Key Luno

1. Login ke [luno.com](https://www.luno.com)
2. Pergi ke **Wallet → Security → API Keys**
3. Klik **"Create New API Key"**
4. Tandakan permissions:
   - ✅ **Read** (Baca baki)
   - ✅ **Trade** (Buat order)
   - ✅ **Send** *(jangan tick kalau tak nak)*
5. Simpan **API Key** dan **API Secret** — ⚠️ hanya ditunjuk sekali!

---

### LANGKAH 2 — Setup Fail .env

1. Dalam folder `backend/`, cari fail `.env.example`
2. **Salin** dan **rename** kepada `.env`:
   ```
   copy .env.example .env
   ```
3. Buka `.env` dan isi:
   ```env
   LUNO_API_KEY=masukkan_api_key_anda
   LUNO_API_SECRET=masukkan_api_secret_anda
   ```

---

### LANGKAH 3 — Setup Backend (Python)

Buka **Command Prompt** dalam folder `backend/`:

```bash
# 1. Buat virtual environment
python -m venv venv

# 2. Aktifkan venv
venv\Scripts\activate

# 3. Install semua library
pip install -r requirements.txt

# 4. Buat database + tables
python -c "from database.models import create_tables; create_tables(); print('DB Ready!')"

# 5. Test connection ke Luno
python -c "from exchange.luno_client import LunoClient; c = LunoClient(); print(c.get_balances())"
```

Jika step 5 tunjuk baki wallet anda → ✅ Berjaya!

---

### LANGKAH 4 — Setup Frontend (Next.js)

Buka **Command Prompt** dalam folder `frontend/`:

```bash
# 1. Install packages
npm install

# 2. Test run
npm run dev
```

Buka browser: **http://localhost:3000**

---

### LANGKAH 5 — Konfigurasi Grid Trading

1. Buka dashboard: **http://localhost:3000**
2. Pergi ke tab **Settings**
3. Untuk setiap pair (BTC, ETH, XRP):

   | Setting | Nilai Cadangan |
   |---|---|
   | Trade Size | RM 35 |
   | Margin % | 2.5% |
   | Base Price | 0 (auto-detect) |

4. Klik **Simpan**

---

### LANGKAH 6 — Start Bot

**Double-click** fail `Start_Bot.bat` — ini akan start:
- ✅ Backend API (port 8000)
- ✅ Frontend Dashboard (port 3000)

Atau jalankan secara manual:

**Terminal 1 (Backend):**
```bash
cd backend
venv\Scripts\activate
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

**Terminal 2 (Frontend):**
```bash
cd frontend
npm run dev
```

---

### LANGKAH 7 — Backfill Chart (Optional — 7 Hari Sejarah)

Untuk chart portfolio nampak smooth dari awal:

```bash
cd backend
venv\Scripts\activate
python create_snapshots_backfill.py
```

---

## 🎯 CARA BOT BERFUNGSI

```
Harga BTC TURUN 2.5% dari Base Price
         ↓
    BOT BELI RM 35
         ↓
Harga BTC NAIK 2.5% dari Base Price
         ↓
    BOT JUAL RM 35
         ↓
     UNTUNG ~RM 1-2 per cycle
```

**Replenish Strategy:**
- Jika crypto dipegang < RM 70 (< 2× trade size)
- Bot akan beli **3× ganda** (RM 105) pada next trigger
- Untuk rebuild buffer dengan cepat

---

## 📊 DASHBOARD FEATURES

| Feature | Penerangan |
|---|---|
| Portfolio Chart | Graf nilai portfolio berubah ikut harga live |
| Per-Pair Cards | Nilai kini + P&L untuk setiap crypto |
| Trade History | Rekod semua buy/sell dengan sebab |
| Bot Status | AKTIF/PAUSE dengan countdown |
| Settings | Konfigurasi per-pair tanpa edit kod |

---

## ❓ SOALAN LAZIM

**Q: Bot tak beli walaupun harga dah turun?**
> Pastikan baki MYR mencukupi (min RM 35) dan bot dalam status AKTIF

**Q: Macam mana nak pause bot?**
> Klik butang "Pause" dalam dashboard atau tutup `Start_Bot.bat`

**Q: Boleh guna untuk selain BTC?**
> Ya! Aktifkan ETH, XRP, atau SOL dalam Settings. SOL masih dalam beta.

**Q: Berapa minimum untuk mula?**
> RM 150+ (RM 35 × 4 pair jika aktifkan semua). BTC sahaja pun boleh dengan RM 70+.

---

## ⚠️ PERINGATAN PENTING

- **JANGAN** kongsi fail `.env` kepada sesiapa
- Bot ini menggunakan **wang sebenar** — monitor selalu
- Crypto adalah aset berisiko — hanya laburkan yang mampu rugi
- Pastikan baki MYR sentiasa ada untuk bot beli

---

## 📞 SUPPORT

Hubungi developer jika ada masalah teknikal.

